import React from 'react';
import './App.css';
function App() {
  return (
    <div>
      <h1>Hello React 200!</h1>
      <p>HTML 적용하기</p>
    </div>
  );
}

export default App;